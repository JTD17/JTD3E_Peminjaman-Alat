<!DOCTYPE html>
<html>
        <meta charset="UTF-8">
        <title> Peminjaman Alat Polinema </title>

        <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
   <head>

 </head>
    <body>
	
    <?php
    include "navbar.php";
    ?>
	<section id="banner">
		<h2>Politeknik Negeri Malang</h2>
		<p>- Laboratorium -</p>
	</section>

    <br><br>
<!--footer-->

<div class="container-fluid" style="background: #000;">
  <p style="text-align: center; padding: 8px; color: white;">Copyright &copy;</p>
</div>

    <?php require_once "templates/footer.php" ?>
        <script type="text/javascript">
        $('.carousel').carousel();
        </script>