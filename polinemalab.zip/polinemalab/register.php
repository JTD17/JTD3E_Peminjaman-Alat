<?php 
	include "templates/header.php";
	session_start();
?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
          <h2 class="page-header">Register Mahasiswa</h2>

          <div class="panel panel-primary">
            <div class="panel panel-heading"> 
                Form Register
            </div> 
            <div class="panel-body">  
                <form action="prosesregister.php" method="post">  
                     <div class ="form-group">
                          <label for="exampleInputPassword1">Nama Lengkap</label>
                          <input type="text"   name="nama" 
                          class="form-control" placeholder="Nama Lengkap..." required>
                    </div>
                   <div class ="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password"   name="password" 
                        class="form-control" placeholder="Password..." required>
                    </div>
                    <label for=" ">Kelas</label>
                     <div class="row">  
                        <div class="col-md-3">
                       <select name="kelas" class="form-control">
                         <option value="" disabled selected>- Pilih Kelas -</option>
                         <option value="3A">JTD 3A</option>
                         <option value="3B">JTD 3B</option>
                         <option value="3C">JTD 3C</option>
						 <option value="3D">JTD 3D</option>
                         <option value="3E">JTD 3E</option>
                       </select>
                     </div>
                     <div class="col-md-3">
                       <select name="prodi" class="form-control">
                         <option value="" disabled selected>- Pilih Prodi -</option>
                         <option value="JTD">Jaringan Telekomunikasi Digital</option>
                         <option value="TT">Teknik Telekomunikasi</option>
                       </select>
                     </div>
                     </div>
                    

              <div class="row" style="margin-top: 15px; margin-left: 5px">
                <button type="submit" class="btn btn-danger">Tambah Data</button>
              <a href="barang.php" class="btn btn-danger">Back</a>
              </div>
        </form>
            </div>
          </div>
    </div>
</div>
<?php include "templates/footer.php"; ?>