<!-- Placed at the end of the document so the pages load faster -->
<html>
  <body>
	<script src="bootstrap/dist/js/jquery.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>